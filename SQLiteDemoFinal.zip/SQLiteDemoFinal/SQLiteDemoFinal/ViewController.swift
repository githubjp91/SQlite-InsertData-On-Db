//
//  ViewController.swift
//  SQLiteDemoFinal
//
//  Created by Mac on 9/24/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit
import SQLite3

class ViewController: UIViewController {
    
    @IBOutlet weak var txtNumber: UITextField!
    @IBOutlet weak var txtCity: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtName: UITextField!
    
    var db:OpaquePointer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let urls = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        
        SQLite()
        
        
    }
    
func SQLite()
    {
        let fileUrl = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true).appendingPathComponent("database.sqlite")
        
        if sqlite3_open(fileUrl.path, &db) != SQLITE_OK
        {
            print("error in opening database")
        }
        if sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS DataTable(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT , email TEXT , number INTEGER , city TEXT)", nil, nil, nil) != SQLITE_OK
        {
             let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error creating table: \(errmsg)")
        }
    
    }
    
    @IBAction func btnSave(_ sender: Any)
    {
        
        let name = txtName.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let email = txtEmail.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let number = txtNumber.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let city = txtCity.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        
        
        if (name?.isEmpty)!
        {
            txtName.layer.borderColor = UIColor.red.cgColor
            print("name is empty")
            return
        }
        if (email?.isEmpty)!
        {
            txtEmail.layer.borderColor = UIColor.red.cgColor
            print("name is email")
            return
            
        }
        if (number?.isEmpty)!
        {
            txtNumber.layer.borderColor = UIColor.red.cgColor
            print("name is number")
            return
        }
        if (city?.isEmpty)!
        {
            txtCity.layer.borderColor = UIColor.red.cgColor
            print("name is city")
            return
        }
        var statement:OpaquePointer?
        
        let SQLITE_TRANSIENT = unsafeBitCast(OpaquePointer(bitPattern: -1), to: sqlite3_destructor_type.self)
        
        let queryString = "INSERT INTO DataTable(name , email , number , city) VALUES (?,?,?,?)"
        
        if sqlite3_prepare(db, queryString, -1, &statement, nil) != SQLITE_OK
        {
            print("error in insert table data")
        }
       
        if sqlite3_bind_text(statement, 1, name, -1, SQLITE_TRANSIENT) != SQLITE_OK
        {
            print("error in binding name")
        }
        if sqlite3_bind_text(statement, 2, email, -1, SQLITE_TRANSIENT) != SQLITE_OK
        {
            print("error in binding email")
        }
        if sqlite3_bind_int(statement, 3, (number! as NSString).intValue) != SQLITE_OK
        {
             print("error in binding number")
        }
        if sqlite3_bind_text(statement, 4, city, -1, SQLITE_TRANSIENT) != SQLITE_OK
        {
            print("error in binding city")
        }
        if sqlite3_step(statement) != SQLITE_DONE
        {
            print("error in insertin data in table")
        }
        
         if sqlite3_close(db) != SQLITE_OK {
            print("Database closed...");
        } else {
            print("Error closing database");
        }
        
         print("Data saved successfully")
        
        txtName.text = ""
        txtEmail.text = ""
        txtNumber.text = ""
        txtCity.text = ""

    }
    

}

